const responsive = {
 320 : {
   items:1
 },
 560 : {
   items:2
 },
 969 : {
   items : 3
 }
}
$(document).ready(function(){
  
  $nav = $('nav');
  $toggleCollapse = $('.toggleCollapse');
  
  /*  click event on toggle menu */
  $toggleCollapse.click(function(){
    $nav .toggleClass('collapse');
  })
  
  // ---owl-carousel for blog
 $('.owl-carousel').owlCarousel({
  loop: true,
  autoplay: false,
  autoplayTimeout: 3000,
  nav: true,
  navText:[$('.owl-navigation.owl-nav-prev')
  responsive:responsive
 });
 
 // click to scroll top 
 $('move-up span').click(function()
  $('html,body')animate((
  scroll Top:0
    ),1000);
 )}
 
});